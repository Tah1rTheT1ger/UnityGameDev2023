using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AfterSphereAttack : StateMachineBehaviour
{
    int isgrounded = 0;
    public Rigidbody2D HornetRigidBody;

    GameObject groundCheck;
    public LayerMask groundLayer;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        HornetRigidBody = animator.GetComponent<Rigidbody2D>();
        groundCheck = GameObject.Find("GroundCheck");
        //Debug.Log(groundCheck.name);
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if(IsGrounded()) {
            animator.SetBool("SphereAttackFinished", true);
        }
        
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    //override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    
    //}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        isgrounded = 1;
    }

    bool IsGrounded()
    {
        return Physics2D.OverlapCircle(groundCheck.transform.position, 0.2f, groundLayer);
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
