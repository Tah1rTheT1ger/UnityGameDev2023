using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEditor;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    // Start is called before the first frame update
    public new Vector3 start;
    public new Vector3 prestart;
    public new Vector3 middle;
    public new Vector3 value;
    public new Vector3 end;
    public float appearTime = 2;
    public float time = 0;
    public int count = 0;
    public float endposition;
    public Rigidbody2D myRigidBody;
    public float speed = 2;

    void Start()
    {
        transform.position = prestart;

    }

    // Update is called once per frame
    void Update()
    {
        movement();
    }

    void movement()
    {
        if (count == 0)
        {
            if (time < appearTime)
            {
                time = time + Time.deltaTime;
            }
            else
            {
                Debug.Log("Line 44\n");
                transform.position = start;
                time = 0;
                count++;
            }
        }
        else if (count == 1)
        {
            if (time < appearTime)
            {
                time = time + Time.deltaTime;
            }
            else
            {
                Debug.Log("Line 58\n");
                transform.position = middle;
                time = 0;
                count++;
            }
        }

        else if (count == 2)
        {
            if (time < appearTime)
            {
                time = time + Time.deltaTime;
            }
            else
            {
                Debug.Log("Line 58\n");
                //Vector3 value = [middle.x, -0.46, middle.z];
                transform.position = value;
                time = 0;
                count++;
            }
        }
        else if (count == 3)
        {
            Debug.Log("Line 67\n");
            myRigidBody.velocity = Vector2.right * speed;

            if (transform.position.x >= endposition)
            {
                myRigidBody.velocity = Vector2.zero;
                //count++;
            }
        }
    }
}
