using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class GDashAttack : StateMachineBehaviour
{
    Rigidbody2D HornetRigidBody;
   // public Rigidbody2D Player;
    public float speed;
    public float RightendPosition;
    public float LeftendPosition;
    public GameObject Player;
    private int direction;
    public GameObject Hornet;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {

        HornetRigidBody = animator.GetComponent<Rigidbody2D>();
        if(Player.transform.position.x > HornetRigidBody.transform.position.x) 
        {
            HornetRigidBody.velocity = Vector2.right * speed;
            direction = 1;
        }
        if (Player.transform.position.x < HornetRigidBody.transform.position.x)
        {
            HornetRigidBody.velocity = Vector2.left * speed;
            direction = -1;
        }
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (direction == 1)
        {
            HornetRigidBody.velocity = Vector2.right * speed;
            if (HornetRigidBody.transform.position.x >= RightendPosition)
            {
                HornetRigidBody.velocity = Vector2.zero;
                animator.SetBool("GDashFinish", true);
                animator.SetBool("GDash", false);
            }
        }
        if(direction == -1) 
        {
            HornetRigidBody.velocity = Vector2.left * speed;
            if (HornetRigidBody.transform.position.x <= LeftendPosition)
            {
                HornetRigidBody.velocity = Vector2.zero;
                animator.SetBool("GDashFinish", true);
                animator.SetBool("GDash", false);
            }
        }
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        Hornet = GameObject.Find("Hornet");
        
        Hornet.GetComponent<HornetCommands>().isFinished = 0;
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
