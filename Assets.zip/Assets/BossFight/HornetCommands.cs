using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;

public class HornetCommands : MonoBehaviour
{
    // Start is called before the first frame update

    public Rigidbody2D HornetRigidBody;
    public int isFinished = 0;
    public float speed;
    public Animator animator;
    private int count = 0;
    //public Transform groundCheck;
    public LayerMask groundLayer;
    private int isgrounded = 0;
    //int PrevAttack = -1;
    public float speedAttack2;
    public float LeftEndDashAttack;
    public float RightendPositionAttack2;

    public int maxHealth = 10;
    int currentHealth;

    private int Attack;
    //public GameObject Sphere;
    void Start()
    {
        // Sphere.GetComponent<SpriteRenderer>().enabled = false;
        currentHealth = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        if (isFinished == 0)
        {
            Attack = Random.Range(0, 3);

            /*if(Attack == PrevAttack ) 
            {
                Attack = (Attack+1) % 3;
            }*/

            Debug.Log("Attack = " + Attack);
            Debug.Log("isFinished = " + isFinished);

            /*if (Input.GetKey(KeyCode.LeftArrow) && isFinished == 0)
            {
                HornetRigidBody.velocity = new Vector2(-speed, HornetRigidBody.velocity.y);
                animator.SetFloat("Speed", speed);
                if (HornetRigidBody.transform.localScale.x < 0)
                {
                    Vector3 scale = HornetRigidBody.transform.localScale;
                    scale.x *= -1;
                    HornetRigidBody.transform.localScale = scale;
                }
                isFinished++;
            }

            if (Input.GetKeyUp(KeyCode.LeftArrow))
            {
                HornetRigidBody.velocity = new Vector2(0, HornetRigidBody.velocity.y);
                animator.SetFloat("Speed", 0);
            }

            if (Input.GetKey(KeyCode.RightArrow) && isFinished == 0)
            {
                HornetRigidBody.velocity = new Vector2(+speed, HornetRigidBody.velocity.y);
                animator.SetFloat("Speed", speed);
                if (HornetRigidBody.transform.localScale.x > 0)
                {
                    Vector3 scale = HornetRigidBody.transform.localScale;
                    scale.x *= -1;
                    HornetRigidBody.transform.localScale = scale;
                }
                isFinished++;
            }

            if (Input.GetKeyUp(KeyCode.RightArrow))
            {
                HornetRigidBody.velocity = new Vector2(0, HornetRigidBody.velocity.y);
                animator.SetFloat("Speed", 0);
            }

            if (Input.GetKeyDown(KeyCode.Space) && count == 0 && isFinished == 0)
            {
                isgrounded = 0;
                HornetRigidBody.velocity = Vector2.up * speed;
                animator.SetBool("Jump", true);
                count++;
                isFinished++;
            }*/

            if (isgrounded == 1)
            {
                count = 0;
                animator.SetBool("Jump", false);
            }

            /*if (Input.GetKeyDown(KeyCode.X) && isFinished == 0)
            {
                animator.SetBool("GDash", true);
                isFinished++;
            }

            if(Input.GetKeyDown(KeyCode.Z) && isFinished == 0)
            {
                HornetRigidBody.velocity = Vector2.up * speed;
                animator.SetBool("SpherePreAnticipation", true);
                isFinished++;
            }

            if (Input.GetKeyDown(KeyCode.S) && isFinished == 0)
            {
                animator.SetBool("NeedleThrow", true);
                isFinished++;
            }*/

            if (Attack == 0 && isFinished == 0 && isgrounded==1)
            {
                animator.SetBool("GDash", true);
                isFinished++;
                // PrevAttack = Attack;
            }

            if (Attack == 1 && isFinished == 0 && isgrounded==1)
            {
                HornetRigidBody.velocity = Vector2.up * speed;
                animator.SetBool("SpherePreAnticipation", true);
                isFinished++;
                // PrevAttack = Attack;
            }

            if (Attack == 2 && isFinished == 0 && isgrounded==1)
            {
                animator.SetBool("NeedleThrow", true);
                isFinished++;
                // PrevAttack = Attack;
            }
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        isgrounded = 1;
        animator.SetBool("Jump", false);
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth < 0) Die();
    }

    private void Die()
    {
        GetComponent<Collider2D>().enabled = false;
        GetComponent<SpriteRenderer>().enabled = false;
        this.enabled = false;
    }

}