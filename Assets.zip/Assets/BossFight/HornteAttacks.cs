using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;

public class HornteAttacks : MonoBehaviour
{
    // Start is called before the first frame update

    public Rigidbody2D HornetRigidBody;
    public Rigidbody2D NeedleRigidBody;
    public float RightendPosition;
    public float RightendPositionAttack2;
    public float UpendPositionAttack3;
    public float UpendPositionAttack4;
    public float LeftendPosition;
    public Quaternion RightendRotation;
    public Quaternion LeftendRotation;
    public Quaternion RotationAttack3;
    private Quaternion InitialRotationAttack3;
    public float speed;
    public float speedAttack2;
    public float speedAttack3;
    private float StopAttack3=0;
    private float StopAttack4=0;
    private float r;
    public float maxCircleSizeAttack4;
    private int count = 0;
    private float gravity;
    private Vector3 InitialNeedlePosition;
    public Vector3 VelocityAttack3;
    public Vector3 FinalPositionAttack4;
    public GameObject explosive;
    private float timer;
    public float RadiusIncreaseRate = 2;

    public Transform groundCheck;
    public LayerMask groundLayer;

    void Start()
    { 

    }

    // Update is called once per frame
    void Update()
    {
        attack4();
    }



    void attack1()
    {
        if (count == 0)
        {
            InitialNeedlePosition = NeedleRigidBody.transform.position;
            Debug.Log("Line 39\n");
            NeedleRigidBody.velocity = Vector2.right * speed;
            count++;
        }

        if (NeedleRigidBody.position.x >= RightendPosition)
        {
            if (count == 1)
            {
                Debug.Log("Line 44\n");
                NeedleRigidBody.velocity = Vector2.zero;
                count++;
            }
        }



        if (count == 2)
        {
            Debug.Log("Line 54\n");
            NeedleRigidBody.velocity = Vector2.left * speed;
            count++;
        }

        Debug.Log(NeedleRigidBody.position);
        if (NeedleRigidBody.transform.position.x <= LeftendPosition && count == 3)
        {
            Debug.Log("Line 61\n");
            NeedleRigidBody.velocity = Vector2.zero;
            NeedleRigidBody.transform.rotation = LeftendRotation;
            NeedleRigidBody.transform.position = InitialNeedlePosition;
            count++;
        }
    }

    void attack2()
    {
        HornetRigidBody.velocity = Vector2.right * speedAttack2;

        if(HornetRigidBody.transform.position.x >= RightendPositionAttack2)
        {
            HornetRigidBody.velocity = Vector2.zero;
        }
    }

    void attack3()
    {
        if(count == 0)
        {
            NeedleRigidBody.simulated = false;
            HornetRigidBody.velocity = Vector2.up * speedAttack3;
           // NeedleRigidBody.velocity = Vector2.up * speedAttack3;
            count++;
        }


        if(HornetRigidBody.transform.position.y >= UpendPositionAttack3 && count == 1)
        {

            HornetRigidBody.velocity = VelocityAttack3;
            StopAttack3 = 1;
            count++;
        }

        if(IsOnGround() && StopAttack3 == 1 && count == 2) {
            HornetRigidBody.velocity = Vector2.zero;
            NeedleRigidBody.simulated = true;
            StopAttack3 = 0;
            count++;
        }
    }

    bool IsOnGround()
    {
        return Physics2D.OverlapCircle(groundCheck.position, 0.2f, groundLayer);
    }

    void attack4()
    {
        if (count == 0)
        {
            r = 1;
            NeedleRigidBody.simulated = false;
            HornetRigidBody.velocity = Vector2.up * speedAttack3;
            count++;
        }

        if (HornetRigidBody.transform.position.y >= UpendPositionAttack3 && count == 1)
        {
            HornetRigidBody.velocity = Vector2.zero;
            Instantiate(explosive, transform.position, transform.rotation);
            gravity = HornetRigidBody.gravityScale;
            HornetRigidBody.gravityScale = 0;
            count++;
        }

        if(count == 2)
        {
            if (timer < RadiusIncreaseRate)
            {
                timer = timer + Time.deltaTime;
            }
            else
            {
                explosive.transform.localScale = new Vector3(r, r, r);
                r++;
                if (r >= maxCircleSizeAttack4)
                {
                    count++;
                }
                timer = 0;
            }
        }

        if (count == 3)
        {
            Destroy(explosive);
            HornetRigidBody.gravityScale = gravity;
            HornetRigidBody.velocity = FinalPositionAttack4;
            count++;
            StopAttack4 = 1;
        }

        if(IsOnGround() && count == 4 && StopAttack4 == 1)
        {
            HornetRigidBody.velocity = Vector2.zero;
            NeedleRigidBody.simulated = true;
            StopAttack4 = 0;
        }
    }

    
}
