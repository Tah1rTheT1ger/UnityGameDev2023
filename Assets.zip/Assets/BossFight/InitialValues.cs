using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class InitialValues : StateMachineBehaviour
{
    Rigidbody2D HornetRigidBody;
    public GameObject Player;
    int count = 0;
    public GameObject Hornet;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        Debug.Log("Now FSM is in idle state.");
        //Debug.Log(("Line 16"));
        //command.isFinished = 0;
        
        Hornet = GameObject.Find("Hornet");
        Player = GameObject.Find("PlayerMC");

        Hornet.GetComponent<HornetCommands>().isFinished = 0;

        Debug.Log(Hornet.GetComponent<HornetCommands>().isFinished);
        //Debug.Log(Hornet.name);
        //Debug.Log(Player.name);
        
        animator.SetBool("GDashFinish", false);
        animator.SetBool("NeedleAttackFinished", false);
        animator.SetBool("SphereAttackFinished", false);


        HornetRigidBody = animator.GetComponent<Rigidbody2D>();

        Debug.Log(HornetRigidBody.transform.position.x);
        Debug.Log(Player.transform.position.x);

        flip();
       
    }

    void flip()
    {
        if (Player.transform.position.x > HornetRigidBody.transform.position.x)
        {
           // Debug.Log("Line 19\n");
            //Debug.Log(HornetRigidBody.transform.localScale.x);
            if (HornetRigidBody.transform.localScale.x > 0)
            {
                // Flip the sprite horizontally by multiplying the x component by -1
                HornetRigidBody.transform.localScale = new Vector3(-1 * HornetRigidBody.transform.localScale.x, HornetRigidBody.transform.localScale.y, HornetRigidBody.transform.localScale.z);
                // count++;
            }
        }

        if (Player.transform.position.x < HornetRigidBody.transform.position.x)
        {
            //Debug.Log("Line 31\n");
            //Debug.Log(HornetRigidBody.transform.localScale.x);
            if (HornetRigidBody.transform.localScale.x < 0)
            {
              //  Debug.Log("Luine 36\n");
                // Flip the sprite horizontally by multiplying the x component by -1
                HornetRigidBody.transform.localScale = new Vector3(-1 * HornetRigidBody.transform.localScale.x, HornetRigidBody.transform.localScale.y, HornetRigidBody.transform.localScale.z);
                // count++;
            }
        }
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    /*override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if(Hornet.GetComponent<HornetCommands>().isFinished == 1)
        {
            Hornet.GetComponent<HornetCommands>().isFinished = 0;
        }
        //animator.SetBool("GDashFinished", false);
    }*/

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        animator.SetBool("GDashFinish", false);
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}