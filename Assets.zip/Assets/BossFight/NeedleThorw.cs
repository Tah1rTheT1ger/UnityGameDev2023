using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NeedleThorw : StateMachineBehaviour
{
    public GameObject Needle;
    GameObject InstantiatedNeedle;
    Rigidbody2D HornetRigidBody;
    Rigidbody2D NeedleRigidBody;
    public GameObject Player;
    public float speed;
    private int dir = 1;
    int count = 0;
    int direction = 1;
    public float RightendPosition;
    public float LeftendPosition;

    Vector3 SpawnPosition;

    float PlayerPosition;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        Player = GameObject.Find("PlayerMC");

        SpawnPosition = new Vector3(animator.transform.position.x, animator.transform.position.y - 1, animator.transform.position.z);

        PlayerPosition = Player.transform.position.x;
        HornetRigidBody = animator.GetComponent<Rigidbody2D>();
        InstantiatedNeedle = Instantiate(Needle, SpawnPosition, HornetRigidBody.transform.rotation);
        NeedleRigidBody = InstantiatedNeedle.GetComponent<Rigidbody2D>();
        if (PlayerPosition > HornetRigidBody.transform.position.x)
        {
            NeedleRigidBody.velocity = Vector2.right * speed;
            direction = 1;
        }
        if (PlayerPosition < HornetRigidBody.transform.position.x)
        {
            NeedleRigidBody.velocity = Vector2.left * speed;
            direction = -1;
        }
        //Debug.Log(direction);
        NeedleRigidBody.transform.localScale = new Vector3(direction * NeedleRigidBody.transform.localScale.x, NeedleRigidBody.transform.localScale.y, NeedleRigidBody.transform.localScale.z);
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (count < 2)
        {
            if (direction == 1)
            {
                //Debug.Log("Line 47");
                NeedleRigidBody.velocity = Vector2.right * speed * dir;
                if (NeedleRigidBody.transform.position.x >= (PlayerPosition + 5) && count == 0)
                {
                   // Debug.Log("Line 51");
                    NeedleRigidBody.velocity = Vector2.left * speed * dir;
                    dir = -1;
                    count++;
                }
                if (NeedleRigidBody.transform.position.x < (HornetRigidBody.transform.position.x + 5) && count == 1)
                {
                    //Debug.Log("Line 58");
                    Destroy(InstantiatedNeedle);
                    //NeedleRigidBody.velocity = Vector2.zero;
                    animator.SetBool("NeedleAttackFinished", true);
                    animator.SetBool("NeedleThrow", false);
                    count++;
                    dir = 1;
                }
            }

            if (direction == -1)
            {
               // Debug.Log(InstantiatedNeedle.transform.position.x);
                //Debug.Log("Line 70");
               // Debug.Log(NeedleRigidBody.transform.position.x);
                NeedleRigidBody.velocity = Vector2.left * speed * dir;
                if (NeedleRigidBody.transform.position.x < (PlayerPosition - 5) && count == 0)
                {
                   // Debug.Log("Line 74");
                    NeedleRigidBody.velocity = Vector2.right * speed * dir;
                    dir = -1;
                    count++;
                }
                if (NeedleRigidBody.transform.position.x > (HornetRigidBody.transform.position.x - 5) && count == 1)
                {
                   // Debug.Log("Line 81");
                    Destroy(InstantiatedNeedle);
                    //NeedleRigidBody.velocity = Vector2.zero;
                    animator.SetBool("NeedleAttackFinished", true);
                    animator.SetBool("NeedleThrow", false);
                    count++;
                    dir = 1;
                }
            }
        }
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        count = 0;    
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
