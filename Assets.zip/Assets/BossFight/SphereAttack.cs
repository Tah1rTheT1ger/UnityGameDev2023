using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SphereAttack : StateMachineBehaviour
{
    Rigidbody2D HornetRigidBody;
    public float UpperBoundSphereAttack;
    public float speed;
    public Animator SphereAnimator;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        HornetRigidBody = animator.GetComponent<Rigidbody2D>();
       // HornetRigidBody.gravityScale = 0;
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        HornetRigidBody.velocity = Vector2.up * speed;
        if(HornetRigidBody.transform.position.y >= UpperBoundSphereAttack)
        {
            HornetRigidBody.velocity = Vector2.zero;
            HornetRigidBody.gravityScale = 0;
            animator.SetBool("SpherePreAnticipation", false);
            animator.SetBool("SphereAnticipation", true);
        }    
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    //override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    
    //}

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
