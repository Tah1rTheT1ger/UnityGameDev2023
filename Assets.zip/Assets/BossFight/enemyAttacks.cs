using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class enemyAttacks : MonoBehaviour
{
    // Start is called before the first frame update

    public Rigidbody2D enemyRigidBody;
    public Rigidbody2D bulletRigidBody;
    public new Vector3 startAttack1;
    public new Vector3 startAttack2;
    public new Vector3 startAttack3;
    public new Vector3 BulletStartPosition;
    public new Quaternion BulletStartRotation;
    public new Vector3 BulletVelocity1;
    private int  ForBulletVelocity1 = 1;
    public new Vector3 BulletVelocity2;
    private int ForBulletVelocity2;
    public float speed;
    public float deadEndAttack1;
    public float leftDeadEndAttack3;
    public float rightDeadEndAttack3;
    private int count = 0;
    private int forstopAttack2 = 0;
    public int forAttack1 = 0;
    private int forAttack2 = 0;
    public GameObject bullet;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        /* if(forAttack1 == 1)
         {
             attack1();
         }
         if(forAttack2 == 1)
         {
             attack2();

         }*/

        attack3();
    }

    void attack1()
    {
        if (count == 0)
        {
            transform.position = startAttack1;
            count++;
        }
        enemyRigidBody.velocity = Vector2.right * speed;

        if (transform.position.x >= deadEndAttack1)
        {
            enemyRigidBody.velocity = Vector2.zero;
            count = 0;
            forAttack1 = 0;
            forAttack2 = 1;
        }
    }

    void attack2()
    {
        if (count == 0)
        {
            transform.position = startAttack2;
            count++;
        }
        
        enemyRigidBody.velocity = Vector2.down * speed;
        if(forstopAttack2 == 1)
        {
            enemyRigidBody.velocity = Vector2.zero;
            count = 0;
            forstopAttack2 = 0;
            forAttack2 = 0;
            forAttack1 = 1;
        }
        
    }

    void attack3()
    {
       if(count == 0)
       {
            transform.position = startAttack3;
          //  enemyRigidBody.constraints = (RigidbodyConstraints2D)RigidbodyConstraints.FreezePosition;
            enemyRigidBody.velocity = Vector2.zero;
            //enemyRigidBody.gravityScale = 0f;
            // StartCoroutine(Launch());
            GameObject instantiatedBullet = Instantiate(bullet, BulletStartPosition, BulletStartRotation);
            bulletRigidBody = instantiatedBullet.GetComponent<Rigidbody2D>();
            enemyRigidBody.velocity = Vector2.zero;
            count++;
       }


        if (ForBulletVelocity1 == 1)
        {
            bulletRigidBody.velocity = BulletVelocity1;
            enemyRigidBody.velocity = Vector2.zero;
            ForBulletVelocity1 = 0;
        }

        if(bulletRigidBody.position.x >= leftDeadEndAttack3)
        {
            bulletRigidBody.velocity = BulletVelocity2;
           // Destroy(bulletRigidBody.gameObject);
        }

        if(bulletRigidBody.position.x <= rightDeadEndAttack3)
        {
            bulletRigidBody.velocity = Vector2.zero;
        }

       /* if(bulletRigidBody.position.x <= rightDeadEndAttack3)
        {
            Destroy(bullet);
        }*/


    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        forstopAttack2 = 1;
    }

    /*new IEnumerator Launch()
    {
        float gravity = enemyRigidBody.gravityScale;
        enemyRigidBody.gravityScale = 0f;
        yield return new WaitUntil( () => var/funtion);
        enemyRigidBody.gravityScale = gravity;
    }*/



}
