using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyMotion : MonoBehaviour
{
    // Start is called before the first frame update
    public Rigidbody2D myRigidBody;
    public new Vector3 prestart;
    public new Vector3 start;
    public new Vector3 middle;
    public new Vector3 end;
    public new Vector2 velocityAction2;
    private int forAction1 = 1;
    private int forAction2 = 0;
    private int forAction3 = 0;
    private int forAction33 = 0;
    public float endposition;
    public float endpositionAction2X;
    public float endpositionAction2Y;
    public float speed;
    public float speedAction2;

    void Start()
    {
        transform.position = prestart;
    }

    // Update is called once per frame
    void Update()
    {
        if (forAction1 == 1)
        {
           // Debug.Log("Line 26\n");
            action1();
           // forAction1 = 0;
        }

        if(forAction2 == 1)
        {
           // Debug.Log("Line 32\n");
            action2();
        }

        if(forAction3 == 1 && forAction33 == 1)
        {
            action3();
        }
    }

    void action1()
    {
        Debug.Log("Line 67\n");
        myRigidBody.velocity = Vector2.right * speed;

        if (transform.position.x >= endposition)
        {
            Debug.Log("Line 50\n");
            myRigidBody.velocity = Vector2.zero;
            forAction1 = 0;
            forAction2 = 1;
        }
    }

    void action2()
    {
        Debug.Log("Lin 48\n");
        myRigidBody.velocity = velocityAction2 * speedAction2;
        /*float rotationSpeed = 5.0f;
        Quaternion targetRotation = Quaternion.Euler(0.0f, 0.0f, 152.55f);
        transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, Time.deltaTime * rotationSpeed);*/
        if (transform.position.x <= endpositionAction2X || transform.position.y >= endpositionAction2Y)
        {
            myRigidBody.velocity = Vector2.zero;
            forAction2 = 0;
            forAction3 = 1;

            
        }
    }

    void action3()
    {
        Debug.Log("Line 77\n");
        myRigidBody.velocity = Vector2.right * speed;

        if (transform.position.x >= endposition)
        {
            Debug.Log("Line 83\n");
            myRigidBody.velocity = Vector2.zero;
           // forAction1 = 1;
        }
    }


      private void OnCollisionEnter2D(Collision2D collision)
      {
          Debug.Log("Line 73\n");
          forAction33 = 1;
      }


}