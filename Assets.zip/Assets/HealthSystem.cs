using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HealthSystem : MonoBehaviour
{
    public int maxHealth = 5;
    public int health;
    private bool canGetHit;
    AsyncOperation asyncLoad;

    [SerializeField] LayerMask enemyLayer;

    // Start is called before the first frame update
    void Start()
    {
        canGetHit = true;
        health = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        if (GotHit() && canGetHit)
        {
            StartCoroutine(ScreenFreeze());
        }

        if (health == 0)
            PlayerDied();
    }

    bool GotHit()
    {
        //return Physics2D.OverlapArea(new Vector2(transform.position.x - 0.58f, transform.position.y+0.9f), new Vector2(transform.position.x + 1f, transform.position.y+0.37f), enemyLayer);
        return Physics2D.OverlapCircle(this.transform.position, 0.5f, enemyLayer);
    }

    void PlayerDied()
    {
        StartCoroutine(ScreenFreeze());
        health = maxHealth;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        //LoadScene(0);
        health = maxHealth;
    }

    IEnumerator ScreenFreeze()
    {
        health -= 1;
        canGetHit = false;
        Time.timeScale = 0.001f;
        yield return new WaitForSeconds(0.0005f);
        Time.timeScale = 1;
        yield return new WaitForSeconds(1f);
        canGetHit = true;
    }

    async void LoadScene(int loadScene)
    {
        asyncLoad = SceneManager.LoadSceneAsync(loadScene, LoadSceneMode.Single);
        asyncLoad.allowSceneActivation = false;

        while (!asyncLoad.isDone)
        {
            if (asyncLoad.progress >= 0.9f)
            {
                asyncLoad.allowSceneActivation = true;
            }

            await Task.Yield();
        }


    }
}