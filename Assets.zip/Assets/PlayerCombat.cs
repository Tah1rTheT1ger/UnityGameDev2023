using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerCombat : MonoBehaviour
{
    public Animator animator;
    

    public int speed = 6;
    private bool isRightFacing = true;
    public bool WallJumpUnlocked = false;

    //Dash
    public bool DashUnlocked = true;
    private int dashStrength = 48;
    private float dashTime = 0.2f;
    public float Cooldown = 0.1f;
    private bool canDash, isDashing;
    [SerializeField] private TrailRenderer trailRenderer;

    //Jump
    public int jumpPower = 13;
    public float SecondJump = 0.8f;

    //Double Jump
    public bool DoubleJump = true;
    private bool jumps;

    //Wall Sliding
    private bool isSliding;
    private int WallSlideSpeed = 2;

    //Wall Jump
    private bool isWallJumping;
    private float wallJumpingDirection, wallJumpingTime = 0.3f;
    private float wallJumpingDuration = 0.3f, wallJumpingCounter;
    private Vector2 wallJumpingPower = new Vector2(4f, 10f);

    //attack
    private float attackRange = 1.5f,attackRate = 2f;
    public int attackDamage = 40;
    [SerializeField] public Transform attackPoint;
    [SerializeField] public LayerMask enemyLayer;


    [SerializeField] public LayerMask groundLayer;
    [SerializeField] public Transform groundCheck;
    [SerializeField] public LayerMask wallLayer;
    [SerializeField] public Transform wallCheck;

    [SerializeField] Rigidbody2D body;
    [SerializeField] Renderer attackSprite;

    float nextAttackTime = 0f;
    bool downHit;

    private void Start()
    {
        canDash = true;
        isDashing = false;

        trailRenderer = GetComponent<TrailRenderer>();
        trailRenderer.emitting = false;

        jumps = DoubleJump;
        attackSprite = attackPoint.GetComponent<Renderer>();
        body = GetComponent<Rigidbody2D>();
        attackSprite.enabled = false;
        downHit = false;

        isWallJumping = false;
        isSliding = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (DashUnlocked && canDash && Input.GetKeyDown(KeyCode.C))
            StartCoroutine(Dash());
        if (isDashing)
            return;

        if(Time.time >= nextAttackTime) { 
            if (Input.GetKeyDown(KeyCode.X) & !IsWalled())
            {
                downHit = false;
                if(Input.GetKey(KeyCode.DownArrow) && !IsGrounded())
                {
                    attackPoint.position = new Vector2(transform.position.x, transform.position.y-2.5f);
                    downHit = true;
                    animator.SetBool("IsDownSlashing", true);
                }
                else if (Input.GetKey(KeyCode.UpArrow))
                {
                    attackPoint.position = new Vector2(transform.position.x, transform.position.y + 2.5f);
                    animator.SetBool("IsUpSlashing", true);
                }

                attackSprite.enabled = true;
                StartCoroutine(nextAttack());
                Attack();
                nextAttackTime = Time.time + 1f/attackRate;
            }
        }

        movement();
        Jump();

        if (WallJumpUnlocked)
        {
            WallSlide();
            WallJump();
        }
    }

    void movement()
    {
        if (!isWallJumping)
        {
            //left and right movement
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                body.velocity = new Vector2(-speed, body.velocity.y);
                if (isRightFacing) Flip();
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                body.velocity = new Vector2(speed, body.velocity.y);
                if (!isRightFacing) Flip();
            }
            else if (!Input.GetKey(KeyCode.LeftArrow) || !Input.GetKey(KeyCode.RightArrow))
                body.velocity = new Vector2(0, body.velocity.y);

            //idle moving animation
            animator.SetFloat("Speed", Mathf.Abs(body.velocity.x));
        }
    }

    void Jump()
    {
        if (IsGrounded())
        {
            jumps = DoubleJump;
            animator.SetFloat("ySpeed", 0);
            animator.SetBool("IsGrounded", true);
        }

        //jump (existing lr velocity + upward velocity)
        if (Input.GetKeyDown(KeyCode.Z))
        {
            if (!IsGrounded())
            {
                if (jumps)
                {
                    jumps = false;
                    body.velocity = new Vector2(body.velocity.x, jumpPower * SecondJump);
                    //Jump Animation
                    animator.SetFloat("ySpeed", +1);    
                    animator.SetBool("IsGrounded", false);
                }
            }
            else
            {
                //Jump Animation
                animator.SetFloat("ySpeed", +1);
                animator.SetBool("IsGrounded", false);
                body.velocity = new Vector2(body.velocity.x, jumpPower);
            }
        }

        if (Input.GetKeyUp(KeyCode.Z) && body.velocity.y > 0f)
        {
            body.velocity = new Vector2(body.velocity.x, body.velocity.y * 0.5f);
        }

        //if velocity is -ve, jump ending animation
        if(body.velocity.y < 0f)
        {
            animator.SetBool("IsGrounded", false);
            animator.SetFloat("ySpeed", -1);
        }
    }

    void WallSlide()
    {
        //Sliding animation

        if (IsWalled() && !IsGrounded() && body.velocity.x != 0)
        {
            jumps = DoubleJump;
            canDash = true;
            isSliding = true;

            //sliding animation
            animator.SetBool("IsSliding", true);

            body.velocity = new Vector2(body.velocity.x, Mathf.Clamp(body.velocity.y, -WallSlideSpeed, float.MaxValue));
        }
        else
        {
            isSliding = false;
            animator.SetBool("IsSliding", false);
        }
        
    }

    void WallJump()
    {
        if (isSliding)
        {
            isWallJumping = false;
            wallJumpingDirection = -transform.localScale.x;
            wallJumpingCounter = wallJumpingTime;

            CancelInvoke(nameof(StopWallJumping));
        }
        else
        {
            wallJumpingCounter -= Time.deltaTime;
        }

        if (Input.GetKeyDown(KeyCode.Z) && wallJumpingCounter > 0f)
        {
            isWallJumping = true;
            body.velocity = new Vector2(wallJumpingDirection * wallJumpingPower.x, wallJumpingPower.y);
            wallJumpingCounter = 0f;

            if (transform.localScale.x != wallJumpingDirection)
            {
                isRightFacing = !isRightFacing;
                Vector3 localScale = transform.localScale;
                localScale.x *= -1f;
                transform.localScale = localScale;
            }

            Invoke(nameof(StopWallJumping), wallJumpingDuration);
        }
    }

    void StopWallJumping()
    {
        isWallJumping = false;
        Flip();
    }

    void Attack()
    {
        Collider2D[] enemiesHit = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayer);
        foreach (Collider2D enemy in enemiesHit)
        {
            enemy.GetComponent<enemyScript>().TakeDamage(attackDamage);
            if (downHit)
            {
                jumps = DoubleJump;
                body.velocity = new Vector2(body.velocity.x, jumpPower * SecondJump);
               

                //jump up animation
                animator.SetBool("IsGrounded", false);
                animator.SetFloat("ySpeed", +1);
            }
        }
    }

    private IEnumerator nextAttack()
    {
        //attack animation for duration of 0.1sec
        animator.SetBool("IsAttacking", true);

        yield return new WaitForSeconds(0.1f);
        attackSprite.enabled = false;
        attackPoint.position = new Vector2 (transform.position.x+transform.localScale.x*1.6f,transform.position.y);
        animator.SetBool("IsAttacking", false);

        animator.SetBool("IsUpSlashing", false);
        animator.SetBool("IsDownSlashing", false);
    }

    bool IsGrounded()
    {
        return Physics2D.OverlapCircle(groundCheck.position, 0.2f, groundLayer);
    }

    bool IsWalled()
    {
        return Physics2D.OverlapCircle(wallCheck.position, 0.2f, wallLayer);
    }

    void Flip()
    {
        Vector3 currentScale = body.transform.localScale;
        currentScale.x *= -1;
        body.transform.localScale = currentScale;
        isRightFacing = !isRightFacing;
    }
    private IEnumerator Dash()
    {
        //Dash Animation begin
        animator.SetBool("IsDashing", true);

        canDash = false;
        isDashing = true;
        float originalGravity = body.gravityScale;
        body.gravityScale = 0;
        body.velocity = new Vector2(transform.localScale.x * dashStrength, 0);
        trailRenderer.emitting = true;
        yield return new WaitForSeconds(dashTime);

        //Dash Animation end
        animator.SetBool("IsDashing", false);

        body.gravityScale = originalGravity;
        isDashing = false;
        trailRenderer.emitting = false;
        yield return new WaitForSeconds(Cooldown);

        yield return new WaitUntil(() => IsGrounded());
        canDash = true;
    }

}
 