using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hornetAnimation : MonoBehaviour
{
    Animator animator;
    enemyScript e;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        e = GetComponent<enemyScript>();
    }

    // Update is called once per frame
    void Update()
    {
        if(e.currentHealth <= 0)
        {
            animator.SetBool("IsDeath", true);
        }
    }
}
