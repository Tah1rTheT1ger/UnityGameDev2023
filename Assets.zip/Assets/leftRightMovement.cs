using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class leftRightMovement : MonoBehaviour
{
    public Rigidbody2D body;
    private Vector2 a;

    public float leftend;
    public float rightend;

    // Start is called before the first frame update
    void Start()
    {
        a = body.position;
    }

    // Update is called once per frame
    void Update()
    {
        if (body.transform.position.x <= leftend)
        {
            body.velocity = Vector2.right * 4;
            if(body.transform.localScale.x > 0)
            {
                body.transform.localScale = new Vector3(body.transform.localScale.x * -1, body.transform.localScale.y, body.transform.localScale.z);
            }
        }
        if (body.transform.position.x >= rightend)
        {
            body.velocity = Vector2.left * 4;
            if (body.transform.localScale.x < 0)
            {
                body.transform.localScale = new Vector3(body.transform.localScale.x * -1, body.transform.localScale.y, body.transform.localScale.z);
            }
        }
            

    }

}
